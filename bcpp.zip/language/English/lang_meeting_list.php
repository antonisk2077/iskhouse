<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1_1'] 			= "Meeting List";
$_data['text_2'] 			= "Meeting";
$_data['text_3'] 			= "Add Meeting";
$_data['text_4'] 			= "Meeting Entry Form";
$_data['text_5'] 			= "Meeting Issue Date";
$_data['text_6'] 			= "Meeting Title";
$_data['text_7'] 			= "Meeting Description";
$_data['text_15'] 			= "Added Meeting Information Successfully";
$_data['text_16'] 			= "Update Meeting";
$_data['view_text'] 		= "Meeting Details";
$_data['text_17'] 			= "Updated Meeting Information Successfully";
$_data['text_18'] 			= "Deleted Meeting Information Successfully";
$_data['delete_confirm'] 	= "Are you sure you want to delete this Meeting Information ?";
?>