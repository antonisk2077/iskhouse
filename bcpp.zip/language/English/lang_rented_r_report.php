<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Rented Report";
$_data['text_2'] 		= "Rented Report Form";
$_data['text_3'] 		= "Select Month";
$_data['text_4'] 		= "Select Year";
$_data['text_5'] 		= "Payment Status";
$_data['text_6'] 		= "PAID";
$_data['text_7'] 		= "DUE";
$_data['text_8'] 		= "Select";


?>