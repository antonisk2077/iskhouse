
<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 			= "Tenant Notice Board";
$_data['text_12'] 			= "Employee Notice Board";
$_data['text_13'] 			= "Owner Notice Board";
$_data['text_2'] 			= "Notice Entry Form";
$_data['text_2a'] 			= "Notice Title";
$_data['text_2b'] 			= "Notice Date";
$_data['text_3'] 			= "Notice Title";
$_data['text_33'] 			= "Notice Status";
$_data['text_3a'] 			= "Notice Status";
$_data['text_3b'] 			= "Publish Now";
$_data['text_3bb'] 			= "Notice";
$_data['text_3c'] 			= "Disable";
$_data['text_4'] 			= "Notice List";
$_data['text_5'] 			= "Please Reset First Before Insert and You can Publish one notice at a time that will display tenant dashboard";
$_data['text_55'] 			= "Please Reset First Before Insert and You can Publish one notice at a time that will display employee dashboard";
$_data['text_555'] 			= "Please Reset First Before Insert and You can Publish one notice at a time that will display owner dashboard";
$_data['text_6'] 			= "Notice Details";
$_data['text_7'] 			= "Added Notice Information Successfully";
$_data['text_8'] 			= "Updated Notice Information Successfully";
$_data['text_9'] 			= "Deleted Notice Information Successfully";

//validate
$_data['v_1'] 				= "Notice Title Required !!!";
$_data['v_2'] 				= "Notice Description Required !!!";
$_data['v_3'] 				= "Notice Created Date Required !!!";

//confirm
$_data['confirm'] 			= "Are you sure you want to delete this Notice ?";

?>