<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Year Setup";
$_data['text_2'] 		= "Year Entry Form";
$_data['text_3'] 		= "Year Name";
$_data['text_4'] 		= "Year List";
$_data['text_5'] 		= "Added Year Information Successfully";
$_data['text_6'] 		= "Updated Year Information Successfully";
$_data['text_7'] 		= "Deleted Year Information Successfully";
$_data['text_8'] 		= "Year Details";

//validation
$_data['required_1'] 		= "Year text required !!!";
$_data['confirm_delete'] 	= "Are you sure you want to delete this Year ?";

?>