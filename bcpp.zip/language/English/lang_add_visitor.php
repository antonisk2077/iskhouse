<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add New Visitor";
$_data['text_2'] 		= "Visitor";
$_data['text_3'] 		= "Add Visitor";
$_data['text_4'] 		= "Visitor Entry Form";
$_data['text_5'] 		= "Entry Date";
$_data['text_6'] 		= "Name";
$_data['text_7'] 		= "Mobile";
$_data['text_8'] 		= "Address";
$_data['text_9'] 		= "Floor No";
$_data['text_10'] 		= "Select Floor";
$_data['text_11'] 		= "Unit No";
$_data['text_12'] 		= "Select Unit";
$_data['text_13'] 		= "In Time";
$_data['text_14'] 		= "Out Time";
$_data['text_15'] 		= "Added Visitor Successfully";
$_data['text_16'] 		= "Update Visitor";
$_data['text_17'] 		= "Updated Visitor Successfully";

//validation
$_data['r1'] 			= "Visitor Issue Date Required !!!";
$_data['r2'] 			= "Visitor Name Required !!!";
$_data['r3'] 			= "Visitor Mobile No Required !!!";
$_data['r4'] 			= "Visitor Address Required !!!";
$_data['r5'] 			= "Select Visitor visit floor no.";
$_data['r6'] 			= "Select Visitor visit unit no.";
$_data['r7'] 			= "Visitor In Time Required!!!";
$_data['r8'] 			= "Visitor Out Time Required !!!";
?>