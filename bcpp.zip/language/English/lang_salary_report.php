<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Employee Salary Report";
$_data['text_2'] 		= "Report";
$_data['text_3'] 		= "Employee Salary Report Form";
$_data['text_4'] 		= "Select Employee";
$_data['text_6'] 		= "Select Month";
$_data['text_66'] 		= "Select Year";
$_data['text_7'] 		= "Submit";

$_data['validation'] 	= "Please select at least one or more fields";

?>