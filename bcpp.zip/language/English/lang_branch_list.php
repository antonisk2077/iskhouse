<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add Building";
$_data['text_1_1'] 		= "Update Building";
$_data['text_2'] 		= "Building";
$_data['text_3'] 		= "Building Entry Form";
$_data['text_4'] 		= "Name ";
$_data['text_5'] 		= "Email";
$_data['text_6'] 		= "Contact No";
$_data['text_7'] 		= "Address";
$_data['text_8'] 		= "Status";
$_data['text_9'] 		= "Enable";
$_data['text_10'] 		= "Disable";
$_data['text_11'] 		= "Added Building Information Successfully";
$_data['text_12'] 		= "Updated Building Information Successfully";
$_data['text_13'] 		= "Deleted Building Information Successfully";
$_data['text_14']		= "Building List";
$_data['text_15'] 		= "Building Name";
$_data['text_16']  		= "Building Details";
$_data['text_17'] 		= "Dashboard";
$_data['text_19'] 		= "Home";
$_data['text_20'] 		= "Settings";

$_data['text_144'] 		= "Security Guard Mobile No";
$_data['text_155'] 		= "Secretary Mobile No";
$_data['text_166'] 		= "Moderator Mobile No";
$_data['text_177'] 		= "Building Construction Year";
$_data['text_188'] 		= "Building Image";


$_data['text_199'] 		= "Builder Information";
$_data['text_200'] 		= "Company Name";
$_data['text_211'] 		= "Company Phone No";
$_data['text_222'] 		= "Company Address";
$_data['text_233'] 		= "Status";

?>