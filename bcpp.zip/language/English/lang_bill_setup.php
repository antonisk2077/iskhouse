<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 			= "Bill Type Setup ";
$_data['text_2'] 			= "Bill Type Entry Form";
$_data['text_3'] 			= "Bill Type";
$_data['text_4'] 			= "Bill Type List";
$_data['text_5'] 			= "Please Reset First Before Insert";
$_data['text_6'] 			= "Bill Type Details";
$_data['text_7'] 			= "Added Bill Type Information Successfully";
$_data['text_8'] 			= "Updated Bill Type Information Successfully";
$_data['text_9'] 			= "Deleted Bill Type Information Successfully";

//validate
$_data['v_1'] 				= "Bill Type Required !!!";

//confirm
$_data['confirm'] 			= "Are you sure you want to delete this Bill Type ?";

?>