<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_title_text'] 				= "নতুন রক্ষণাবেক্ষণ খরচ যোগ";
$_data['add_msg'] 						= "রক্ষণাবেক্ষণ খরচ সফলভাবে যোগ করা হয়েছে";
$_data['update_title_text'] 			= "রক্ষণাবেক্ষণ খরচ পরিবর্তন";
$_data['update_msg'] 					= "রক্ষণাবেক্ষণ খরচ সফলভাবে পরিবর্তন হয়েছে";
$_data['maintenance_cost'] 				= "রক্ষণাবেক্ষণ খরচ";
$_data['add_m_cost'] 					= "রক্ষণাবেক্ষণ খরচ যোগ";
$_data['m_cost_entry_form'] 			= "রক্ষণাবেক্ষণ খরচ এন্ট্রি ফর্ম";
$_data['date'] 							= "তারিখ";
$_data['month'] 						= "মাস";
$_data['select_month'] 					= "মাস নির্বাচন";
$_data['year'] 							= "বছর";
$_data['select_year'] 					= "বছর নির্বাচন";
$_data['text_1'] 						= "রক্ষণাবেক্ষণ শিরোনাম";
$_data['text_2'] 						= "পরিমাণ"; 
$_data['text_3'] 						= "বিস্তারিত";

?>