<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['floor_list_title'] 							= "মেঝে তালিকা";
$_data['add_new_floor_information_breadcam'] 		= "মেঝে তথ্য";
$_data['delete_floor_information'] 					= "মেঝে তথ্য সফলভাবে মুছে ফেলেছেন।";
$_data['floor_no'] 									= "মেঝে সংখ্যা";
$_data['floor_details']								= "মেঝে বিস্তারিত";
$_data['add_floor'] 								= "ফ্লোর যোগ";
$_data['delete_msg'] 								= "আপনি কি এই মেঝেটি মুছে ফেলতে চান ?";
$_data['add_msg'] 									= "ফ্লোরের তথ্য সফলভাবে যুক্ত হয়েছে";
$_data['update_msg'] 								= "ফ্লোরের তথ্য সফলভাবে পরিবর্তন হয়েছে";

?>