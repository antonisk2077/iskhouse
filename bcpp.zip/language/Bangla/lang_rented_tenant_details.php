<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়া বিস্তারিত";
$_data['text_2'] 		= "মাস নাম";
$_data['text_3'] 		= "সর্বমোট পরিমাণ";
$_data['text_4'] 		= "প্রদানের তারিখ";
$_data['text_5'] 		= "ভাড়াটিয়া নাম";
$_data['text_6'] 		= "ই-মেইল";
$_data['text_7'] 		= "যোগাযোগ";
$_data['text_8'] 		= "ঠিকানা";
$_data['text_9'] 		= "মেঝে সংখ্যা";
$_data['text_10'] 		= "ইউনিট সংখ্যা";
$_data['text_11'] 		= "ভাড়া";
$_data['text_12'] 		= "পানি বিল";
$_data['text_13'] 		= "বিদ্যুৎ বিল";
$_data['text_14'] 		= "গ্যাস বিল";
$_data['text_15'] 		= "নিরাপত্তা বিল";
$_data['text_16'] 		= "ইউটিলিটি বিল";
$_data['text_17'] 		= "অন্যান্য বিল";
$_data['text_18'] 		= "মোট ভাড়া";
$_data['text_19'] 		= "ড্যাশবোর্ড";

?>