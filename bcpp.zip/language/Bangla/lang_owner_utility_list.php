<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_owner_list_utility_title'] 			= "মালিক ইউটিলিটি তালিকা";
$_data['owner_utility'] 							= "মালিক ইউটিলিটি";
$_data['add_owner_utility'] 						= "মালিক ইউটিলিটি যোগ";
$_data['owner_utility_details'] 					= "মালিক ইউটিলিটি বিস্তারিত";
$_data['add_owner_utility_entry_form'] 				= "মালিক ইউটিলিটি এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "মেঝে সংখ্যা";
$_data['add_new_form_field_text_2'] 				= "মেঝে নির্বাচন";
$_data['add_new_form_field_text_3'] 				= "ইউনিট সংখ্যা";
$_data['add_new_form_field_text_4'] 				= "ইউনিট নির্বাচন";
$_data['add_new_form_field_text_5'] 				= "মাস নির্বাচন";
$_data['add_new_form_field_text_6'] 				= "ভাড়াটের নাম";
$_data['add_new_form_field_text_7'] 				= "ভাড়া";
$_data['add_new_form_field_text_8'] 				= "পানি বিল";
$_data['add_new_form_field_text_9'] 				= "বিদ্যুৎ বিল";
$_data['add_new_form_field_text_10'] 				= "গ্যাস বিল";
$_data['add_new_form_field_text_11'] 				= "নিরাপত্তা বিল";
$_data['add_new_form_field_text_12'] 				= "ইউটিলিটি বিল";
$_data['add_new_form_field_text_13'] 				= "অন্যান্য বিল";
$_data['add_new_form_field_text_14'] 				= "মোট ভাড়া";
$_data['add_new_form_field_text_15'] 				= "প্রদানের তারিখ";
$_data['add_new_form_field_text_16'] 				= "মাসের নাম";
$_data['add_new_form_field_text_17'] 				= "বছরের নাম";
$_data['add_new_form_field_text_18'] 				= "ভাড়া";
$_data['added_owner_utility_successfully'] 			= "মালিক ইউটিলিটি তথ্য সফলভাবে যোগ করা হয়েছে";
$_data['update_owner_utility_successfully'] 		= "মালিক ইউটিলিটি তথ্য সফলভাবে পরিবর্তন করা হয়েছে";
$_data['delete_owner_utility_information'] 			= "মালিক ইউটিলিটি তথ্য সফলভাবে মুছে ফেলা হয়েছে";
?>