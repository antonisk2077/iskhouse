<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_floor_top_title'] 					= "নতুন ফ্লোর যোগ";
$_data['add_new_floor_entry_text'] 					= "মেঝে এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "মেঝে সংখ্যা";
$_data['add_new_floor_information_breadcam'] 		= "মেঝে তথ্য";
$_data['add_new_add_floor_breadcam'] 				= "মেঝে যোগ";
$_data['back_text'] 								= "মেঝে তালিকা";


?>