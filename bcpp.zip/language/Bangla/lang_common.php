<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['save_button_text'] 					= "তথ্য সংরক্ষণ";
$_data['update_button_text'] 				= "তথ্য পরিবর্তন";
$_data['home_breadcam'] 					= "ড্যাশবোর্ড";
$_data['delete_text']						= "মুছে ফেলুন";
$_data['action_text']						= "কার্যকলাপ";
$_data['details_information']				= "বিস্তারিত তথ্য";
$_data['view_text'] 						= "বিস্তারিত দেখুন";
$_data['edit_text'] 						= "সম্পাদন করুন";
$_data['success'] 							= "সফল";
$_data['back_text']							= "তালিকা";
$_data['upload_image'] 						= "চিত্র আপলোড";
$_data['image'] 							= "ছবি";
$_data['submit'] 							= "দাখিল করুন";
$_data['reset'] 							= "রিসেট";
$_data['setting'] 							= "সেটিং";
$_data['reset_text'] 						= "ডাটা যোগ করার পুর্বে অনুগ্রহ করে রিসেট করুন";
$_data['owner_dashboard'] 					= "মালিক ড্যাশবোর্ড";
$_data['dashboard'] 						= "ড্যাশবোর্ড";
$_data['print'] 							= "তথ্য মুদ্রণ";
?>