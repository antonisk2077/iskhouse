<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['add_new_renter'] 							= "নতুন ভাড়াটের যোগ";
$_data['update_rent'] 								= "ভাড়া পরিবর্তন";
$_data['add_new_renter_entry_form'] 				= "ভাড়াটের এন্ট্রি ফর্ম";
$_data['add_new_form_field_text_1'] 				= "ভাড়াটের নাম";
$_data['add_new_form_field_text_2'] 				= "ইমেইল";
$_data['add_new_form_field_text_3'] 				= "পাসওয়ার্ড";
$_data['add_new_form_field_text_4'] 				= "ফোন";
$_data['add_new_form_field_text_5'] 				= "ঠিকানা";
$_data['add_new_form_field_text_6'] 				= "জাতীয় পরিচয়পত্র";
$_data['add_new_form_field_text_7'] 				= "মেঝে সংখ্যা";
$_data['add_new_form_field_text_8'] 				= "প্রাপ্য ইউনিট সংখ্যা";
$_data['add_new_form_field_text_9'] 				= "অগ্রিম ভাড়া";
$_data['add_new_form_field_text_10'] 				= "প্রতি মাসে ভাড়া";
$_data['add_new_form_field_text_11'] 				= "প্রদানের তারিখ";
$_data['add_new_form_field_text_12'] 				= "ভাড়া মাস";
$_data['add_new_form_field_text_13'] 				= "ভাড়া বছর";
$_data['add_new_form_field_text_14'] 				= "অবস্থা";
$_data['add_new_form_field_text_15'] 				= "ছবি";
$_data['add_new_form_field_text_16'] 				= "সক্রিয়";
$_data['add_new_form_field_text_17'] 				= "মেয়াদোত্তীর্ণ";
$_data['select_floor'] 								= "মেঝে নির্বাচন";
$_data['select_unit'] 								= "ইউনিট নির্বাচন";
$_data['select_month'] 								= "মাস নির্বাচন";
$_data['select_year'] 								= "বছর নির্বাচন";
$_data['add_new_renter_information_breadcam'] 		= "ভাড়াটের তথ্য";
$_data['add_new_renter_breadcam'] 					= "ভাড়াটের যোগ";
$_data['added_renter_successfully'] 				= "ভাড়াটে তথ্য সফলভাবে যোগ হয়েছে";
$_data['update_renter_successfully'] 				= "ভাড়াটে তথ্য সফলভাবে পরিবর্তন হয়েছে";
$_data['delete_renter_information'] 				= "ভাড়াটে তথ্য সফলভাবে মুছে ফেলেছেন।";

?>