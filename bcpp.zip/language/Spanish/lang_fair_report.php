<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Fare Collection Report";
$_data['text_2'] 		= "Report";
$_data['text_3'] 		= "Fare Collection Report Form";
$_data['text_4'] 		= "Select Floor";
$_data['text_5'] 		= "Select Unit";
$_data['text_6'] 		= "Select Month";
$_data['text_7'] 		= "Submit";

?>