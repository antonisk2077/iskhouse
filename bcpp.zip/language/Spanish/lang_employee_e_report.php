<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Salary Report";
$_data['text_2'] 		= "Salary Report Form";
$_data['text_3'] 		= "Select Month ";
$_data['text_4'] 		= "Select Year";

?>