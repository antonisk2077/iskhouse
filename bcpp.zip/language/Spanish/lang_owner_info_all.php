<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Owner Collection Information";
$_data['text_2'] 		= "Fare Collection Date";
$_data['text_4'] 		= "Owner Name";
$_data['text_5'] 		= "Floor";
$_data['text_6'] 		= "Unit";
$_data['text_7'] 		= "Month";
$_data['text_8'] 		= "Rent Per Month";
$_data['text_9'] 		= "Gas Bill";
$_data['text_10'] 		= "Electric Bill";
$_data['text_11'] 		= "Water Bill";
$_data['text_12'] 		= "Security Bill";
$_data['text_13'] 		= "Utility Bill";
$_data['text_14'] 		= "Other Bill";
$_data['text_15'] 		= "Total";
$_data['text_16'] 		= "Print Information";


?>