<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Fund List";
$_data['text_2'] 		= "Owner Name";
$_data['text_3'] 		= "Month";
$_data['text_4'] 		= "Year";
$_data['text_5'] 		= "Date";
$_data['text_6'] 		= "Amount";
$_data['text_7'] 		= "Purpose";
$_data['text_8'] 		= "Fund Details";
$_data['text_9'] 		= "Total";
$_data['text_10'] 		= "Issue Date";

?>