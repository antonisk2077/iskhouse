</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
  <div class="pull-right hidden-xs"> <b>Version</b> 3.0 </div>
  <strong>Copyright &copy; 2014-<?php echo date('Y');?> <a target="_blank" href="http://sakosys.com">sakosys.com</a></strong> </footer>
<!-- /.control-sidebar -->
<div class='control-sidebar-bg'></div>
</div>
<!-- ./wrapper -->
<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo WEB_URL; ?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<!-- SlimScroll -->
<script src="<?php echo WEB_URL; ?>assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<!-- FastClick -->
<script src='<?php echo WEB_URL; ?>assets/plugins/fastclick/fastclick.min.js'></script>
<!-- AdminLTE App -->
<script src="<?php echo WEB_URL; ?>assets/dist/js/app.min.js" type="text/javascript"></script>
<!-- Demo -->
<script src="<?php echo WEB_URL; ?>assets/dist/js/demo.js" type="text/javascript"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo WEB_URL; ?>assets/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="<?php echo WEB_URL; ?>assets/plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo WEB_URL; ?>assets/plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo WEB_URL; ?>assets/dist/js/jquery.mask.min.js"></script>
<script src="<?php echo WEB_URL; ?>assets/dist/js/common.js" type="text/javascript"></script>
<script src="<?php echo WEB_URL; ?>assets/dist/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script src="<?php echo WEB_URL; ?>assets/dist/js/dataTables.tableTools.min.js" type="text/javascript"></script>
<script src="<?php echo WEB_URL; ?>assets/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
<input type="hidden" id="web_url" value="<?php echo WEB_URL; ?>" />
</body></html>