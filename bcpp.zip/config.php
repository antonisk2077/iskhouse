<?php
define('CURRENCY', 'Rp');
define('WEB_URL', 'https://test.coderdot-workshop.xyz/');
#define('WEB_URL', 'https://e4ea-112-78-153-102.ap.ngrok.io/ams/');
define('ROOT_PATH', '/home/jbkwqyei/TheCDR/test.coderdot-workshop.xyz/');
error_reporting(0);

define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'jbkwqyei_coder');
define('DB_PASSWORD', 'jbkwqyei_coder');
define('DB_DATABASE', 'jbkwqyei_coder');
$link = new mysqli(DB_HOSTNAME,DB_USERNAME,DB_PASSWORD,DB_DATABASE);?>
